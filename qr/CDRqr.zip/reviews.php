<!DOCTYPE html>
<html lang="en">
<?php
include('includes/head.php');
?>
<body>
    <div class="page-wrapper">
        <?php
            include('includes/navbar2.php');
            include('qr/reviews.php');
            include('includes/footer.php');
            include('includes/redes.php');   
        ?>
    </div>
    <?php
        include('includes/extras.php');
        include('includes/scripts.php');
    ?>
</body>

</html>