 <!--Site Footer Start-->
 <footer class="site-footer" style="background-color: #2e5863; margin-top: 2rem;">
     <div class="container">
         <div class="site-footer__bottom">
             <div class="row justify-content-center">
                 <div class="col-md-12 text-center">
                     <p class="site-footer__bottom-text">© Santo Pulpo 2024. Diseñado por
                         <a href="https://site.bananagroup.mx/" target="_blank">Banana Marketing Group</a>
                     </p>
                 </div>
             </div>
         </div>
     </div>
 </footer>
 <!--Site Footer End-->