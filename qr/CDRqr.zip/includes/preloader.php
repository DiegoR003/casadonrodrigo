<div class="preloader">
    <div class="preloader__image"></div>
</div>
<!-- /.preloader -->